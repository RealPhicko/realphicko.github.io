#pragma once

#define MAX_AUDIO_SIZE 512

enum struct DataType
{
	Null,
	Login,
	Quit,
	Sound,
	SoundSettings,
};

template<unsigned int BufferSize = 512>
class AudioWriter
{
	char myBuffer[BufferSize] = {};
	char* myBufferPtr = myBuffer;
	char* myBufferEnd = nullptr;
	char* myMessageEnd = nullptr;
	bool myCanWrite = true;

	bool BufferOut(size_t aSizeOfData)
	{
		if ((rsize_t)(myBufferEnd - myBuffer) < aSizeOfData)
		{
			printf("\033[31mOut of Buffer!!\033[0m \n");
			return true;
		}

		return false;
	}

	// Use To Write Single Piece of Data
	template<typename T>
	bool WriteData(const T& data)
	{
		if (myBuffer + sizeof(T) >= myBufferEnd)
			return false;

		memcpy(myBufferPtr, &data, sizeof(T));
		myBufferPtr += sizeof(T);

		return true;
	}

	// Use To Write Array or String
	template<typename T>
	bool WriteData(const T* data, size_t count)
	{
		if (myBuffer + sizeof(T) * count >= myBufferEnd)
			return false;

		memcpy(myBufferPtr, data, sizeof(T) * count);
		myBufferPtr += sizeof(T) * count;

		return true;
	}

public:
	AudioWriter()
	{
		myCanWrite = true;
		myBufferEnd = myBuffer + sizeof(myBuffer);
	}

	bool AddLogin()
	{
		if (BufferOut(sizeof(DataType)) == true)
			return false;

		WriteData(DataType::Login);

		return true;
	}

	bool AddLoginResponse(unsigned short aIndex)
	{
		if (BufferOut(sizeof(DataType) + sizeof(unsigned short)) == true)
			return false;

		WriteData(DataType::Login);
		WriteData(aIndex);

		return true;
	}

	bool AddQuit()
	{
		if (BufferOut(sizeof(DataType)) == true)
			return false;

		WriteData(DataType::Quit);

		return true;
	}

	bool AddQuitResponce(unsigned short aIndex)
	{
		if (BufferOut(sizeof(DataType) + sizeof(unsigned short)) == true)
			return false;

		WriteData(DataType::Quit);
		WriteData(aIndex);

		return true;
	}

	bool AddSoundSettings(unsigned char aChannelCount, unsigned int aHertz)
	{
		if (BufferOut(sizeof(DataType) + sizeof(unsigned char) + sizeof(unsigned int)) == true)
			return false;

		WriteData(DataType::SoundSettings);
		WriteData(aChannelCount);
		WriteData(aHertz);

		return true;
	}

	bool AddSoundSettingsResponse(unsigned short aIndex, unsigned char aChannelCount, unsigned int aHertz)
	{
		if (BufferOut(sizeof(DataType) + sizeof(int) + sizeof(unsigned char) + sizeof(unsigned int)) == true)
			return false;

		WriteData(DataType::SoundSettings);
		WriteData(aIndex);
		WriteData(aChannelCount);
		WriteData(aHertz);

		return true;
	}

	bool AddSound(unsigned int length, char* aSoundData)
	{
		//size_t size = (size_t)aSoundData;

		if (BufferOut(sizeof(DataType) + sizeof(unsigned int) + sizeof(char) * length) == true)
			return false;

		WriteData(DataType::Sound);
		WriteData(length);
		WriteData(aSoundData);

		return true;
	}

	bool AddSoundResponse(unsigned short aIndex, unsigned int length, char* aSoundData)
	{
		//size_t size = (size_t)aSoundData;

		if (BufferOut(sizeof(DataType) + sizeof(unsigned short) + sizeof(unsigned int) + sizeof(char) * length) == true)
			return false;

		WriteData(DataType::Sound);
		WriteData(aIndex);
		WriteData(length);
		WriteData(aSoundData);

		return true;
	}

	bool IsWriting()
	{
		return myCanWrite;
	}

	char* GetFinalMessage()
	{
		return myBuffer;
	}
};

namespace AudioRead
{
	template<typename T>
	inline static bool ReadData(char const*& buffer, const char* bufferEnd, T& data)
	{
		if (buffer + sizeof(T) >= bufferEnd)
			return false;

		memcpy(&data, buffer, sizeof(T));
		buffer += sizeof(T);

		return true;
	}

	template<typename T>
	inline static bool ReadData(char const*& buffer, const char* bufferEnd, T* data, size_t count)
	{
		if (buffer + sizeof(T) * count >= bufferEnd)
			return false;

		memcpy(data, buffer, sizeof(T) * count);
		buffer += sizeof(T) * count;

		return true;
	}

	inline static DataType GetType(char const*& buffer, const char* bufferEnd)
	{
		DataType result;

		if (!ReadData(buffer, bufferEnd, result))
			return DataType::Null;

		return result;
	}

	inline static unsigned short GetId(char const*& buffer, const char* bufferEnd)
	{
		unsigned short result;

		if (!ReadData(buffer, bufferEnd, result))
			return 0;

		return result;
	}
}