#include "VoiceChatRecorder.h"
#include "ChatManager.h"
#include "VoiceWriter.h"

#include <fmod.hpp>

//#ifndef _RETAIL
//
//#include <fmod_errors.h>
//
//#endif // _DEBUG

extern bool CheckFMODErr(const FMOD_RESULT& aResult, std::string aExtra = "");

std::pair<unsigned int, char*>  VoiceChatRecorder::Update()
{
    FMOD::System* fSys = ClientChatManager::GetInstance()->GetVoiceChatFmodSystem();
    FMOD_RESULT fRes;

    unsigned int recordPos = 0;
    fRes = fSys->getRecordPosition(myRecordIndex, &recordPos);

    if (CheckFMODErr(fRes, "Recording Update Failed"))
            return { 0, nullptr };

    unsigned int recordDelta = (recordPos >= lastRecordPos) ? (recordPos - lastRecordPos) : (recordPos + myRecordLength - lastRecordPos);

    if (recordDelta == 0)
    {
        return { 0, nullptr };
    }

    unsigned int len = 0;

    myRecord->lock(lastRecordPos, min(recordDelta, MAX_AUDIO_SIZE), &currentData, nullptr, &len, 0);
    myRecord->unlock(currentData, nullptr, len, 0);

    lastRecordPos = recordPos;

    char* dataPtr = (char*)currentData + '\0';

    return { len, dataPtr };
}

bool VoiceChatRecorder::SetRecordingIndex(unsigned int aIndex)
{
    FMOD::System* fSys = ClientChatManager::GetInstance()->GetVoiceChatFmodSystem();

    FMOD_RESULT fRes;

    fRes = fSys->getRecordDriverInfo(aIndex, NULL, 0, NULL, &myRate, 0, &myChannels, NULL);

    if (CheckFMODErr(fRes, std::to_string(aIndex) + "is Out of range"))
    {
        myHasRecord = false;
        return false;
    }

    myRate = min(myRate, RATE_LIMIT);
    myRecordIndex = aIndex;
    myHasRecord = true;

    ClientChatManager::GetInstance()->SendSoundSettings((unsigned char)myChannels, myRate);

    if (myActive == true)
    {
        StartRecord();
    }

    return true;
}

void VoiceChatRecorder::StartRecord()
{
    if (myRecord != nullptr)
    {
        StopRecord();
    }

    FMOD_CREATESOUNDEXINFO exinfo = { 0 };
    exinfo.cbsize = sizeof(FMOD_CREATESOUNDEXINFO);
    exinfo.numchannels = myChannels;
    exinfo.format = FMOD_SOUND_FORMAT_PCM16;
    exinfo.defaultfrequency = myRate;
    exinfo.length = (myRate * sizeof(short) * myChannels);

    FMOD::System* fSys = ClientChatManager::GetInstance()->GetVoiceChatFmodSystem();

    FMOD_RESULT fRes = fSys->createSound(0, FMOD_CREATESAMPLE | FMOD_LOOP_NORMAL | FMOD_OPENUSER, &exinfo, &myRecord);
    if (CheckFMODErr(fRes, "Couldn't create Sound"))
        return;

    fRes = fSys->recordStart(myRecordIndex, myRecord, true);
    if (CheckFMODErr(fRes, "Couldn't start Record"))
        return;

    fRes = myRecord->getLength(&myRecordLength, FMOD_TIMEUNIT_PCM);
    if (CheckFMODErr(fRes, "Couldn't get Length"))
        return;

    myActive = true;
}

void VoiceChatRecorder::StopRecord()
{
    ClientChatManager::GetInstance()->GetVoiceChatFmodSystem()->recordStop(myRecordIndex);
    myRecord->release();
    myRecord = nullptr;
    myActive = false;
}

bool VoiceChatRecorder::IsRecording()
{
    return myHasRecord == true && myActive == true;
}
