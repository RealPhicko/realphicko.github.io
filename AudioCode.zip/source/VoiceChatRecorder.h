#pragma once
#include <utility>

class ClientChatManager;

namespace FMOD { class Sound; }

#define RATE_LIMIT 16000

class VoiceChatRecorder
{
	friend ClientChatManager;

	FMOD::Sound* myRecord = nullptr;

	bool myActive = false;
	bool myHasRecord = false;

	void* currentData;
	unsigned int lastRecordPos = 0;
	unsigned int myRecordIndex = 0;
	int myRate = 0;
	int myChannels = 0;
	unsigned int myRecordLength = 0;

	VoiceChatRecorder() = default;
	VoiceChatRecorder(const VoiceChatRecorder& blah) = delete;
	
	std::pair<unsigned int, char*> Update();

public:

	bool SetRecordingIndex(unsigned int aIndex);
	void StartRecord();
	void StopRecord();
	bool IsRecording();
};