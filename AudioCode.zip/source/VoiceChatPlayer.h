#pragma once
#include <vector>
//#include <fmod.hpp>

class ClientChatManager;

namespace FMOD { class Channel; class Sound; }

class VoiceChatPlayer
{
	friend ClientChatManager;

	unsigned char myChannelsCount = 2;
	unsigned int myFreq = 16000;
	float myVolume = 1.00f;

	unsigned int myCurrPos = 0;
	unsigned int myLastSize = 0;

	unsigned short myId = 0;
	FMOD::Channel* myChannel = nullptr;
	FMOD::Sound* mySound = nullptr;

	bool is3d = false;

	VoiceChatPlayer(unsigned short aId);
	VoiceChatPlayer() = delete;
	VoiceChatPlayer(const VoiceChatPlayer& blah) = delete;

	void UpdateSound(unsigned int aLength, char* aData);
	void UpdateSoundOld(unsigned int aLength, char* aData);

public:

	void SetVolumeMult(float aVolumeMult);
	float GetVolumeMult();

	void SetToGlobal()
	{
		is3d = false;
	}
	void Set3D(float aPosition[3], float aForward[3], float aUp[3], float aRange, float aVelocity[3] = { 0 }, float aConeWidth = 360.00f);
};