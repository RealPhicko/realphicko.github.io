#include "ChatManager.h"

#include <fmod.hpp>
#include "WS2tcpip.h"

#include "VoiceWriter.h"
#include "VoiceChatRecorder.h"
#include "VoiceChatPlayer.h"
#include <chrono>

#ifndef _RETAIL

#include <debugapi.h>
#include <fmod_errors.h>

#endif // _DEBUG

//#define SKIP_SERVER

bool CheckFMODErr(const FMOD_RESULT& aResult, std::string aExtra = "")
{
    if (aResult != FMOD_RESULT::FMOD_OK)
    {
#ifndef _RETAIL
        OutputDebugStringA(std::string("(" + aExtra + ") FMOD error! (" + std::to_string(aResult) + ") " + FMOD_ErrorString(aResult) + "\n").c_str());
#endif // _DEBUG

        return true;
    }

    return false;
}
void PrintWinSockErr(int aErrorCode, std::string aExtra = "")
{

#ifndef _RETAIL
    OutputDebugStringA(std::string("(" + aExtra + ") Winsock error! (" + std::to_string(aErrorCode) + ")\n").c_str());
#else
    aErrorCode;
    aExtra;
#endif // _RETAIL
}

#pragma region Client

bool ClientChatManager::HasInit()
{
    if (myHasInitialized == false)
    {
#ifndef _RETAIL
        OutputDebugStringA(std::string("Trying to use function in ClientChatManager without initializing!\n").c_str());
#endif // _RETAIL

        return false;
    }

    return true;
}

void ClientChatManager::Update()
{
#ifndef SKIP_SERVER
    char socketBuffer[MAX_AUDIO_SIZE];
    int addrServerSize = sizeof(mySockData.addrServer);
#endif // !SKIP_SERVER

    std::chrono::high_resolution_clock::time_point lastTime = std::chrono::high_resolution_clock::now();
    float maxTime = 1.00f / 60.f; maxTime;
    float time = 0.00f;

    while (myActive == true)
    {
        time += std::chrono::duration<float>(std::chrono::high_resolution_clock::now() - lastTime).count();
        lastTime = std::chrono::high_resolution_clock::now();

#ifndef SKIP_SERVER
        ZeroMemory(socketBuffer, MAX_AUDIO_SIZE);
        const int recv_len = recvfrom(mySockData.udpSocket, socketBuffer, MAX_AUDIO_SIZE, 0, (sockaddr*)&mySockData.addrServer, &addrServerSize);

        if (recv_len == SOCKET_ERROR && WSAGetLastError() != WSAEWOULDBLOCK)
            PrintWinSockErr(WSAGetLastError(), "Failed receiving data from udpSocket");

        if (0 < recv_len)
        {
            const char* buffer = socketBuffer;
            char* bufferEnd = socketBuffer + MAX_AUDIO_SIZE;
            DataType currentType = DataType::Null;

            do
            {
                currentType = AudioRead::GetType(buffer, bufferEnd);

                switch (currentType)
                {
                case DataType::Login:
                {
                    unsigned short aId = AudioRead::GetId(buffer, bufferEnd);
                    myIdToPlayer.emplace(aId, new VoiceChatPlayer(aId));
                }
                    break;

                case DataType::Quit:
                {
                    delete myIdToPlayer.at(AudioRead::GetId(buffer, bufferEnd));
                    myIdToPlayer.erase(AudioRead::GetId(buffer, bufferEnd));
                }
                    break;

                case DataType::SoundSettings:
                {
                    unsigned short aId = AudioRead::GetId(buffer, bufferEnd);

                    unsigned char channelCount;
                    AudioRead::ReadData(buffer, bufferEnd, channelCount);
                    myIdToPlayer.at(aId)->myChannelsCount = channelCount;

                    unsigned int freq;
                    AudioRead::ReadData(buffer, bufferEnd, freq);
                    myIdToPlayer.at(aId)->myFreq = freq;
                }
                    break;

                case DataType::Sound:
                {
                    unsigned short aId = AudioRead::GetId(buffer, bufferEnd);


                    unsigned int len;
                    AudioRead::ReadData(buffer, bufferEnd, len);


                    char* recvData = new char[len];
                    AudioRead::ReadData(buffer, bufferEnd, recvData, len);

                    myIdToPlayer.at(aId)->UpdateSound(len, recvData);

                    delete[] recvData;
                }
                    break;
                }

            } while (currentType != DataType::Null && buffer != bufferEnd);
        }
#endif // !SKIP_SERVER

        fSys->update();

        if (maxTime <= time)
        {
            time = 0;
            if (myRecorder != nullptr)
            {
                if (myRecorder->IsRecording() == false)
                    continue;

                auto recData = myRecorder->Update();

#ifndef SKIP_SERVER

                if (0 < recData.first)
                {
                    AudioWriter soundWrite;
                    soundWrite.AddSound(recData.first, recData.second);

                    if (sendto(mySockData.udpSocket, soundWrite.GetFinalMessage(), MAX_AUDIO_SIZE, 0, reinterpret_cast<sockaddr*>(&mySockData.addrServer), sizeof(mySockData.addrServer)) == SOCKET_ERROR)
                    {
                        if (WSAGetLastError() != WSAEWOULDBLOCK)
                        {
                            PrintWinSockErr(WSAGetLastError(), "Error Sending Message");
                            myActive = false;
                        }
                    }
                }

#endif // !SKIP_SERVER

                static VoiceChatPlayer testPlayer(USHRT_MAX);
                testPlayer.myChannelsCount = (unsigned char)myRecorder->myChannels;
                testPlayer.myFreq = myRecorder->myRate;

                if (0 < recData.first)
                    testPlayer.UpdateSound(recData.first, recData.second);

                //if (myIdToPlayer.find(USHRT_MAX) == myIdToPlayer.end())
                //{
                //    myIdToPlayer.emplace(USHRT_MAX, new VoiceChatPlayer(USHRT_MAX));
                //    myIdToPlayer.at(USHRT_MAX)->myChannelsCount = (unsigned char)myRecorder->myChannels;
                //    myIdToPlayer.at(USHRT_MAX)->myFreq = myRecorder->myRate;
                //}

                //if (0 < recData.first)
                //    myIdToPlayer.at(USHRT_MAX)->UpdateSound(recData.first, recData.second);
            }
        }
    }
}

void ClientChatManager::SendSoundSettings(unsigned char aChannelCount, unsigned int aHertz)
{
    AudioWriter soundWrite;
    soundWrite.AddSoundSettings(aChannelCount, aHertz);

    if (sendto(mySockData.udpSocket, soundWrite.GetFinalMessage(), MAX_AUDIO_SIZE, 0, reinterpret_cast<sockaddr*>(&mySockData.addrServer), sizeof(mySockData.addrServer)) == SOCKET_ERROR)
    {
        if (WSAGetLastError() != WSAEWOULDBLOCK)
        {
            PrintWinSockErr(WSAGetLastError(), "Error Sending Message");
            myActive = false;
        }
    }
}

FMOD::System* ClientChatManager::GetVoiceChatFmodSystem()
{
    if (HasInit() == false)
        return nullptr;

    return fSys;
}

bool ClientChatManager::Initialize(std::wstring aAddress, unsigned short aPort)
{
    if (myHasInitialized )
    { 
#ifdef _DEBUG
        OutputDebugStringA("Chat Manager has already been Initialized()");
#endif // _DEBUG

        return false;
    }

    FMOD_RESULT fRes;

    // set up FMod system
    {
        //FMOD::Debug_Initialize(FMOD_DEBUG_LEVEL_ERROR | FMOD_DEBUG_LEVEL_WARNING);

        fRes = FMOD::System_Create(&fSys);
        if (CheckFMODErr(fRes))
            return false;

        fRes = fSys->init(256, FMOD_INIT_NORMAL, 0);
        if (CheckFMODErr(fRes))
            return false;
    }

    myServerAdress = aAddress;
    myServerPort = aPort;

#ifndef SKIP_SERVER

    // Set up connection to Server
    {
        if (WSAStartup(MAKEWORD(2, 2), &mySockData.winsockData) != 0)
        {
            PrintWinSockErr(WSAGetLastError(), "Failed to Start Winsock");
            return false;
        }

        mySockData.udpSocket = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
        if (mySockData.udpSocket == INVALID_SOCKET)
        {
            PrintWinSockErr(WSAGetLastError(), "Failed to Create UdpSocket");
            return false;
        }

        u_long iMode = true;
        ioctlsocket(mySockData.udpSocket, FIONBIO, &iMode);

        mySockData.addrServer.sin_family = AF_INET;

        InetPton(AF_INET, myServerAdress.c_str(), &mySockData.addrServer.sin_addr.s_addr);

        mySockData.addrServer.sin_port = htons(myServerPort);
    }

    // Send Data to Server
    {
        AudioWriter login;
        login.AddLogin();

        if (sendto(mySockData.udpSocket, login.GetFinalMessage(), MAX_AUDIO_SIZE, 0, reinterpret_cast<sockaddr*>(&mySockData.addrServer), sizeof(mySockData.addrServer)) == SOCKET_ERROR)
        {
            PrintWinSockErr(WSAGetLastError(), "Couldn't Login");
            return EXIT_FAILURE;
        }
    }
    // Await data from server
    {
        char socketBuffer[MAX_AUDIO_SIZE];
        int addrServerSize = sizeof(mySockData.addrServer);
        bool got = false;

        while (got == false)
        {
            ZeroMemory(socketBuffer, MAX_AUDIO_SIZE);
            const int recv_len = recvfrom(mySockData.udpSocket, socketBuffer, MAX_AUDIO_SIZE, 0, (sockaddr*)&mySockData.addrServer, &addrServerSize);

            if (recv_len == SOCKET_ERROR && WSAGetLastError() != WSAEWOULDBLOCK)
                PrintWinSockErr(WSAGetLastError(), "Failed receiving data from udpSocket");

            if (0 < recv_len)
            {
                const char* buffer = socketBuffer;
                char* bufferEnd = socketBuffer + MAX_AUDIO_SIZE;

                if (AudioRead::GetType(buffer, bufferEnd) == DataType::Login)
                {
                    myId = AudioRead::GetId(buffer, bufferEnd);

                    DataType dataType = DataType::Null;
                    
                    do
                    {
                        dataType = AudioRead::GetType(buffer, bufferEnd);

                        switch (dataType)
                        {
                        case DataType::Login:
                        {
                            unsigned short aId = AudioRead::GetId(buffer, bufferEnd);
                            myIdToPlayer.emplace(aId, new VoiceChatPlayer(aId));
                        }
                            break;

                        case DataType::SoundSettings:
                        {
                            unsigned short aId = AudioRead::GetId(buffer, bufferEnd);

                            unsigned char channelCount;
                            AudioRead::ReadData(buffer, bufferEnd, channelCount);

                            unsigned int freq = AudioRead::ReadData(buffer, bufferEnd, freq);
                            myIdToPlayer.at(aId)->myFreq = freq;
                        }
                            break;

                        default:
                            break;
                        }


                    } while (dataType != DataType::Null);

                    got = true;
                }
            }
        }
    }


#endif // !SKIP_SERVER

    myUpdateThread = std::thread(&ClientChatManager::Update, this);

    myActive = true;
    myHasInitialized = true;

    return true;
}

bool ClientChatManager::Initialize(const wchar_t* aAddress, unsigned short aPort)
{
    return Initialize(std::wstring(aAddress), aPort);
}

void ClientChatManager::SetChatPort(unsigned short aPort)
{
    if (HasInit() == false)
        return;

    myServerPort = aPort;
    mySockData.addrServer.sin_port = htons(myServerPort);
}

unsigned int ClientChatManager::GetChatPort()
{
    if (HasInit() == false)
        return 0;

    return myServerPort;
}

unsigned int ClientChatManager::GetInputDevicesCount()
{
    if (HasInit() == false)
        return 0;

    int output;
    fSys->getRecordNumDrivers(NULL, &output);
    return output;
}

std::string ClientChatManager::GetInputDeviceName(unsigned int aIndex)
{
    if (HasInit() == false)
        return "NonInitialized";

    char output[128];
    FMOD_RESULT fRes = fSys->getRecordDriverInfo(aIndex, output, 128, 0, 0, 0, 0, 0);

    if (CheckFMODErr(fRes, (std::to_string(aIndex) + "is out of range")))
    {
        return "Error";
    }

    return std::string(output);
}

VoiceChatRecorder* ClientChatManager::GetRecorder(unsigned int aIndex)
{
    if (HasInit() == false)
        return nullptr;

    if (myRecorder != nullptr)
    {
#ifndef _RETAIL
        OutputDebugStringA(std::string("Trying to create another recorder when one already exists!").c_str());
#endif // !_RETAIL
    }
    else
    {
        myRecorder = new VoiceChatRecorder;
    }


    myRecorder->SetRecordingIndex(aIndex);

    return myRecorder;
}

VoiceChatRecorder* ClientChatManager::GetRecorder()
{
    return myRecorder;
}

std::unordered_map<unsigned short, VoiceChatPlayer*> ClientChatManager::GetVoicePlayers()
{
    return myIdToPlayer;
}

void ClientChatManager::ShutDown()
{
    myActive = false;
    myHasInitialized = false;

    fSys->release();

    delete myRecorder;

    for (auto& it : myIdToPlayer)
        delete it.second;

    myIdToPlayer.clear();

    myUpdateThread.join();
}

#pragma endregion

#pragma region Server

void ServerChatManager::Update()
{
    char socketBuffer[MAX_AUDIO_SIZE];

    while (isRunning == true)
    {
        ZeroMemory(socketBuffer, MAX_AUDIO_SIZE);

        const int recv_len = recvfrom(udpSocket, socketBuffer, MAX_AUDIO_SIZE, 0, (sockaddr*)&addrClient, &addrClientSize);

        if (recv_len == SOCKET_ERROR && WSAGetLastError() != WSAEWOULDBLOCK)
            PrintWinSockErr(WSAGetLastError(), "Server failed receiving data from socket");

        if (0 < recv_len)
        {
            char clientAddress[16]{ 0 };
            inet_ntop(AF_INET, &addrClient.sin_addr, &clientAddress[0], 16);
            const int clientPort = ntohs(addrClient.sin_port);

            std::string addressStr = (std::string(clientAddress) + ":" + std::to_string(clientPort));

            const char* buffer = socketBuffer;
            char* bufferEnd = socketBuffer + MAX_AUDIO_SIZE;

            DataType currentType = DataType::Null;

            bool newLogin = false;
            AudioWriter normal;
            AudioWriter sound;

            // Get Data
            do
            {
                currentType = AudioRead::GetType(buffer, bufferEnd);

                switch (currentType)
                {
                case DataType::Login:
                {
                    connectedAdresses.push_back({ addrClient, addressStr });
                    addressToId.emplace(addressStr, currentId++);
                    addressToSettings.emplace(addressStr, std::pair<unsigned char, unsigned int>(NULL, NULL));
                    newLogin = true;

                    normal.AddLoginResponse(addressToId.at(addressStr));
                }
                    break;
                case DataType::Quit:
                    normal.AddQuitResponce(addressToId.at(addressStr));

                    for (size_t i = 0; i < connectedAdresses.size(); i++)
                    {
                        if (addressToId[connectedAdresses[i].second] == addressToId[addressStr])
                        {
                            connectedAdresses[i] = connectedAdresses.back();
                            connectedAdresses.pop_back();
                            break;
                        }
                    }

                    addressToId.erase(addressStr);
                    addressToSettings.erase(addressStr);

                    break;
                case DataType::Sound:
                {
                    unsigned int sizeOfData;
                    AudioRead::ReadData(buffer, bufferEnd, sizeOfData);
                    char* recvData = new char[sizeOfData];
                    AudioRead::ReadData(buffer, bufferEnd, recvData, sizeOfData);

                    sound.AddSoundResponse(addressToId.at(addressStr), sizeOfData, recvData);
                }
                    break;
                case DataType::SoundSettings:
                {
                    unsigned char channelCount; 
                    unsigned int hertz;

                    AudioRead::ReadData(buffer, bufferEnd, channelCount);
                    AudioRead::ReadData(buffer, bufferEnd, hertz);

                    addressToSettings.at(addressStr) = { channelCount, hertz };
                    normal.AddSoundSettingsResponse(addressToId.at(addressStr), channelCount, hertz);
                }
                    break;
                }

            } while (currentType != DataType::Null && buffer != bufferEnd);

            // Send Data
            for (auto& it : connectedAdresses)
            {
                if (addressToId[it.second] == addressToId[addressStr])
                {
                    if (newLogin == true)
                    {
                        AudioWriter oldData;

                        for (auto cAdd : connectedAdresses)
                        {
                            std::string& stringId = cAdd.second;
                            unsigned short numId = addressToId.at(stringId);

                            oldData.AddLoginResponse(addressToId.at(addressStr));

                            if (numId != addressToId.at(addressStr))
                            {
                                oldData.AddLoginResponse(numId);

                                if (addressToSettings.at(stringId).first != NULL)
                                {
                                    auto& settings = addressToSettings.at(stringId);
                                    oldData.AddSoundSettingsResponse(numId, settings.first, settings.second);
                                }
                            }
                        }


                        if (sendto(udpSocket, oldData.GetFinalMessage(), MAX_AUDIO_SIZE, 0, reinterpret_cast<sockaddr*>(&it.first), sizeof(addrClient)) == SOCKET_ERROR)
                        {
                            if (WSAGetLastError() != WSAEWOULDBLOCK)
                            {
                                PrintWinSockErr(WSAGetLastError(), "Couldn't Send Data from server");
                                break;
                            }
                        }
                    }
                }
                else
                {
                    while (true)
                    {
                        if (sendto(udpSocket, normal.GetFinalMessage(), MAX_AUDIO_SIZE, 0, reinterpret_cast<sockaddr*>(&it.first), sizeof(addrClient)) == SOCKET_ERROR ||
                            sendto(udpSocket, sound.GetFinalMessage(), MAX_AUDIO_SIZE, 0, reinterpret_cast<sockaddr*>(&it.first), sizeof(addrClient)) == SOCKET_ERROR)
                        {
                            if (WSAGetLastError() != WSAEWOULDBLOCK)
                            {
                                PrintWinSockErr(WSAGetLastError(), "Couldn't Send Data from server");
                                break;
                            }
                        }
                        else
                        {
                            break;
                        }
                    }
                }
            }
        }
    }

    printf("Err\n");
}

bool ServerChatManager::Initialize(unsigned short aPort)
{
    if (WSAStartup(MAKEWORD(2, 2), &winsockData) != 0)
    {
        PrintWinSockErr(WSAGetLastError(), "Failed to start Winsock");
        return false;
    }

    udpSocket = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (udpSocket == INVALID_SOCKET)
    {
        PrintWinSockErr(WSAGetLastError(), "Failed to create Socket");
        return false;
    }

    u_long iMode = true;
    ioctlsocket(udpSocket, FIONBIO, &iMode);

    addrServer.sin_family = AF_INET;
    addrServer.sin_addr.s_addr = INADDR_ANY;
    addrServer.sin_port = htons(aPort);

    if (bind(udpSocket, reinterpret_cast<sockaddr*>(&addrServer), sizeof addrServer) == SOCKET_ERROR)
    {
        PrintWinSockErr(WSAGetLastError(), "Failed to bind Socket");
        return false;
    }

    isRunning = true;

    myUpdateThread = std::thread(&ServerChatManager::Update, this);

    return true;
}

void ServerChatManager::ShutDown()
{
    isRunning = false;

    myUpdateThread.join();

    currentId = 0;

    connectedAdresses.clear();
    addressToId.clear();
    addressToSettings.clear();
}

#pragma endregion
