#pragma once

#include <string>
#include <unordered_map>
#include <thread>
#include "WinSock2.h"

namespace FMOD { class System; }
class VoiceChatRecorder;
class VoiceChatPlayer;

class ClientChatManager
{
	struct WinsockData
	{
		SOCKET udpSocket;
		WSADATA winsockData;
		sockaddr_in addrServer{};
	};

	FMOD::System* fSys = nullptr;
	bool myHasInitialized = false;
	bool myActive = false;
	std::thread myUpdateThread;

	std::wstring myServerAdress = L"";
	unsigned short myServerPort = 20040;

	WinsockData mySockData;

	unsigned short myId = 0;
	VoiceChatRecorder* myRecorder = nullptr;
	std::unordered_map<unsigned short, VoiceChatPlayer*> myIdToPlayer;

	ClientChatManager() = default;
	ClientChatManager(const ClientChatManager& aManager) = delete;

	bool HasInit();
	void Update();


public:
	static ClientChatManager* GetInstance()
	{
		static ClientChatManager instance;
		return &instance;
	}

	FMOD::System* GetVoiceChatFmodSystem();
	void SendSoundSettings(unsigned char aChannelCount, unsigned int aHertz);

	bool Initialize(std::wstring aAdress, unsigned short aPort);
	bool Initialize(const wchar_t* aAdress, unsigned short aPort);
	void SetChatPort(unsigned short aPort);
	unsigned int GetChatPort();

	unsigned int GetInputDevicesCount();
	std::string GetInputDeviceName(unsigned int aIndex);
	VoiceChatRecorder* GetRecorder(unsigned int aIndex);
	VoiceChatRecorder* GetRecorder();
	std::unordered_map<unsigned short, VoiceChatPlayer*> GetVoicePlayers();

	void ShutDown();
};

class ServerChatManager
{
	SOCKET udpSocket;
	WSADATA winsockData;
	sockaddr_in addrServer{};
	sockaddr_in addrClient{};
	int addrClientSize = sizeof(addrClient);

	unsigned short currentId = 0;

	std::vector<std::pair<sockaddr_in, std::string>> connectedAdresses;
	std::unordered_map<std::string, unsigned short> addressToId;
	std::unordered_map<std::string, std::pair<unsigned char, unsigned int>> addressToSettings;

	std::thread myUpdateThread;

	bool isRunning = false;

	ServerChatManager() = default;
	ServerChatManager(const ServerChatManager& aManager) = delete;

	void Update();

public:
	static ServerChatManager* GetInstance()
	{
		static ServerChatManager instance;
		return &instance;
	}

	bool Initialize(unsigned short aPort);

	void ShutDown();
};