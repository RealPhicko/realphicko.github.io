#include "VoiceChatPlayer.h"
#include "ChatManager.h"

#include <fmod.hpp>

#include <iostream>

extern bool CheckFMODErr(const FMOD_RESULT& aResult, std::string aExtra = "");

VoiceChatPlayer::VoiceChatPlayer(unsigned short aId)
{
	myId = aId;
}

void VoiceChatPlayer::UpdateSound(unsigned int aLength, char* aData)
{
    FMOD_RESULT fRes;
    FMOD::System* fSys = ClientChatManager::GetInstance()->GetVoiceChatFmodSystem();

    if (mySound != nullptr)
        mySound->release();

    FMOD_CREATESOUNDEXINFO exinfo = { 0 };
    exinfo.cbsize = sizeof(FMOD_CREATESOUNDEXINFO);
    exinfo.numchannels = (int)myChannelsCount;
    exinfo.format = FMOD_SOUND_FORMAT_PCM16;
    exinfo.defaultfrequency = myFreq;
    exinfo.length = (myFreq * sizeof(short) * myChannelsCount);

    //FMOD::Sound* outPutSound = NULL;
    fRes = fSys->createSound(aData, FMOD_OPENMEMORY | FMOD_OPENRAW, &exinfo, &mySound);

    if (CheckFMODErr(fRes, "Couldn't create sound (" + std::to_string(aLength) + ")"))
        return;

    fRes = fSys->playSound(mySound, 0, false, &myChannel);

    if (CheckFMODErr(fRes, "Couldn't create Channel"))
        return;

    myChannel->setVolume(myVolume);
}

void VoiceChatPlayer::UpdateSoundOld(unsigned int aLength, char* aData)
{
    FMOD_RESULT fRes;
    FMOD::System* fSys = ClientChatManager::GetInstance()->GetVoiceChatFmodSystem();

    if (mySound == nullptr)
    {
        FMOD_CREATESOUNDEXINFO exinfo = { 0 };
        exinfo.cbsize = sizeof(FMOD_CREATESOUNDEXINFO);
        exinfo.numchannels = (int)myChannelsCount;
        exinfo.format = FMOD_SOUND_FORMAT_PCM16;
        exinfo.defaultfrequency = myFreq;
        exinfo.length = (myFreq * sizeof(short) * myChannelsCount);

        //FMOD::Sound* outPutSound = NULL;
        fRes = fSys->createSound(aData, FMOD_OPENMEMORY | FMOD_OPENRAW, &exinfo, &mySound);

        if (CheckFMODErr(fRes, "Couldn't create sound (" + std::to_string(aLength) + ")"))
            return;

        //FMOD::Channel* channel = NULL;

        fRes = fSys->playSound(mySound, 0, false, &myChannel);

        if (CheckFMODErr(fRes, "Couldn't create Channel"))
            return;

    }
    else
    {
        fRes = myChannel->setPosition(0, FMOD_TIMEUNIT_PCM);
        if (CheckFMODErr(fRes))
            return;

        void* oldData;
        unsigned int oldDataLength;

        printf(("Test:" + std::to_string(aLength) + "\n").c_str());

        fRes = mySound->lock(0, myFreq * sizeof(short) * myChannelsCount, &oldData, nullptr, &oldDataLength, 0);
        if (CheckFMODErr(fRes, "Couldn't Lock Sound"))
            return;

        //void* newData[2] = { oldData, aData };

        fRes = mySound->unlock(aData, nullptr, aLength, 0);
        if (CheckFMODErr(fRes, "Couldn't Unlock Sound"))
            return;


        //fRes = fSys->playSound(mySound, 0, false, &myChannel);
        //if (CheckFMODErr(fRes))
        //    return;

        myChannel->setPaused(false);
    }

    myCurrPos += aLength;
    myLastSize = aLength;
    myChannel->setVolume(myVolume);
    //outPutSound->release();
}

void VoiceChatPlayer::SetVolumeMult(float aVolumeMult)
{
    myVolume = aVolumeMult;
	//myChannel->setVolume(aVolumeMult);
}

float VoiceChatPlayer::GetVolumeMult()
{
    return myVolume;
}
